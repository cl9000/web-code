



### 
cd app
npm install
修改数据账号密码
npm run dev 启动服务，访问 http://localhost:3000/
