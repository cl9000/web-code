console.log('000==== ' + process.env.MYSQL_HOST);

if (process.env.MYSQL_HOST) module.exports = require('./mysql');
else module.exports = require('./sqlite');
